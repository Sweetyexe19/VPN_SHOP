#--------------------------------------------
#Фото и описание продуктов
mnth1_text = 'Ты получишь ключ,на 1 месяц'
mnth6_text = 'Ты получишь ключ,на 6 месяцев'
mnth12_text = 'Ты получишь ключ,на 12 месяцев'

mnth1_photo = 'https://avatars.mds.yandex.net/i?id=9a1af36100e8b8f0046387cff27adaf8_l-4493789-images-thumbs&n=13' #НУЖНО ОБЯЗАТЕЛЬНО
mnth6_photo = 'https://avatars.mds.yandex.net/i?id=9a1af36100e8b8f0046387cff27adaf8_l-4493789-images-thumbs&n=13' #НУЖНО ОБЯЗАТЕЛЬНО
mnth12_photo = 'https://avatars.mds.yandex.net/i?id=9a1af36100e8b8f0046387cff27adaf8_l-4493789-images-thumbs&n=13' #НУЖНО ОБЯЗАТЕЛЬНО

