import telebot
from telebot import types
import config
import json
import random
import threading
from yoomoney import Quickpay
from yoomoney import Client
import time

bot = telebot.TeleBot(config.token)

# Генерация случайной метки для платежа
def generate_label():
    return ''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789', k=16))

# Создание ссылки для оплаты
def create_payment_link(sum_amount, label):
    quickpay = Quickpay(
        receiver="4100118290009318",  # Ваш номер YooMoney
        quickpay_form="shop",
        targets="Sponsor this project",  # Описание платежа
        paymentType="SB",  # Способ оплаты
        sum=sum_amount,  # Сумма платежа
        label=label  # Уникальная метка
    )
    return quickpay.base_url  # Возвращает ссылку для оплаты

# Проверка статуса платежа
def check_payment_status(label):
    token = config.yoomoney_token  # Ваш токен API YooMoney
    client = Client(token)
    try:
        history = client.operation_history(label=label)
        for operation in history.operations:
            if operation.status == "success":
                return True  # Платеж прошел успешно
    except Exception as e:
        print(f"Ошибка при проверке статуса платежа: {e}")
    return False  # Платеж не прошел

# Получение ключа для подписки
def get_key1():
    with open('keys_1month.json', 'r') as file:
        data = json.load(file)
    if len(data['keys']) > 0:
        key = data['keys'].pop(0)
        with open('keys_1month.json', 'w') as file:
            json.dump(data, file, indent=4)
        return key
    return None

def get_key3():
    with open('keys_3month.json', 'r') as file:
        data = json.load(file)
    if len(data['keys']) > 0:
        key = data['keys'].pop(0)
        with open('keys_3month.json', 'w') as file:
            json.dump(data, file, indent=4)
        return key
    return None

def get_key6():
    with open('keys_6month.json', 'r') as file:
        data = json.load(file)
    if len(data['keys']) > 0:
        key = data['keys'].pop(0)
        with open('keys_6month.json', 'w') as file:
            json.dump(data, file, indent=4)
        return key
    return None

def get_key12():
    with open('keys_12month.json', 'r') as file:
        data = json.load(file)
    if len(data['keys']) > 0:
        key = data['keys'].pop(0)
        with open('keys_12month.json', 'w') as file:
            json.dump(data, file, indent=4)
        return key
    return None

# Проверка статуса оплаты в фоновом потоке
def check_payment_in_background(label, chat_id, subscription_type):
    # Ожидаем 2 минуты (120 секунд) и проверяем статус
    time.sleep(60)
    if check_payment_status(label):
        if subscription_type == '1_month':
            key = get_key1()
        elif subscription_type == '3_month':
            key = get_key3()
        elif subscription_type == '6_month':
            key = get_key6()
        elif subscription_type == '12_month':
            key = get_key12()

        if key:
            bot.send_message(chat_id, f"Оплата прошла успешно! Ваш ключ: {key}")
        else:
            bot.send_message(chat_id, "Все ключи закончились. Попробуйте позже.")
    else:
        bot.send_message(chat_id, "Оплата не прошла. Попробуйте позже.")

@bot.message_handler(commands=['start'])
def start(message):
    bot.delete_message(message.chat.id, message.message_id)

    markup = telebot.types.InlineKeyboardMarkup()
    btn1 = telebot.types.InlineKeyboardButton('🔥Купить VPN', callback_data='btn1')
    btn2 = telebot.types.InlineKeyboardButton('📖Инструкция', callback_data='btn2')
    btn3 = telebot.types.InlineKeyboardButton('💪Преимущества', callback_data='btn3')
    btn4 = telebot.types.InlineKeyboardButton('❌Если не работает VPN', callback_data='btn4')
    markup.add(btn1)
    markup.add(btn2)
    markup.add(btn3)
    markup.add(btn4)
    bot.send_photo(message.chat.id, config.start_photo, caption=config.start_words, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == 'back_to_menu')
def back_to_menu(call):
    start(call.message)


@bot.callback_query_handler(func=lambda call: call.data == 'btn1')
def buy_vpn(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)

    markup = types.InlineKeyboardMarkup()
    month = types.InlineKeyboardButton(config.month1, callback_data='it1')
    six_month = types.InlineKeyboardButton(config.month6, callback_data='it2')
    tw_month = types.InlineKeyboardButton(config.month12, callback_data='it3')
    th_month = types.InlineKeyboardButton(config.month3, callback_data='it4')

    markup.add(month)
    markup.add(th_month)
    markup.add(six_month)
    markup.add(tw_month)
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))
    bot.send_photo(call.message.chat.id, config.buy_photo, caption=config.buy_text, reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == 'it1')
def buy_1_month(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)

    # Генерируем уникальный label для транзакции
    label = generate_label()

    # Создаем ссылку на оплату
    payment_link = create_payment_link(config.cena1, label)  # Цена для 1 месяца — 300 руб.

    markup = types.InlineKeyboardMarkup()
    link = types.InlineKeyboardButton('Перейти к оплате', url=payment_link)
    markup.add(link)
    markup.add(types.InlineKeyboardButton('Оплатил', callback_data=f'check_payment_{label}'))
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))

    # Отправляем пользователю ссылку для оплаты
    bot.send_message(call.message.chat.id, f"Для оплаты подписки на 1 месяц перейдите по ссылке и оплатите в течении 2мин \n После успешной оплаты вы получите ваш ключ в течении двух минут.", reply_markup=markup)

    # Запускаем проверку платежа в отдельном потоке
    threading.Thread(target=check_payment_in_background, args=(label, call.message.chat.id, '1_month')).start()

@bot.callback_query_handler(func=lambda call: call.data == 'it4')
def buy_3_month(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)

    # Генерируем уникальный label для транзакции
    label = generate_label()

    # Создаем ссылку на оплату
    payment_link = create_payment_link(config.cena3, label)  # Цена для 3 месяцев — 900 руб.

    markup = types.InlineKeyboardMarkup()
    link = types.InlineKeyboardButton('Перейти к оплате', url=payment_link)
    markup.add(link)
    markup.add(types.InlineKeyboardButton('Оплатил', callback_data=f'check_payment_{label}'))
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))

    # Отправляем пользователю ссылку для оплаты
    bot.send_message(call.message.chat.id, f"Для оплаты подписки на 3 месяца перейдите по ссылке и оплатите в течении 2мин \n После успешной оплаты вы получите ваш ключ в течении двух минут.", reply_markup=markup)

    # Запускаем проверку платежа в отдельном потоке
    threading.Thread(target=check_payment_in_background, args=(label, call.message.chat.id, '3_month')).start()

@bot.callback_query_handler(func=lambda call: call.data == 'it2')
def buy_6_month(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    label = generate_label()
    payment_link = create_payment_link(config.cena6, label)  # Цена для 6 месяцев — 2000 руб.

    markup = types.InlineKeyboardMarkup()
    link = types.InlineKeyboardButton('Перейти к оплате', url=payment_link)
    markup.add(link)
    markup.add(types.InlineKeyboardButton('Оплатил', callback_data=f'check_payment_{label}'))
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))

    bot.send_message(call.message.chat.id, f"Для оплаты подписки на 6 месяцев перейдите по ссылке и оплатите в течении 2мин \n После успешной оплаты вы получите ваш ключ в течении двух минут.", reply_markup=markup)

    # Запускаем проверку платежа в отдельном потоке
    threading.Thread(target=check_payment_in_background, args=(label, call.message.chat.id, '6_month')).start()

@bot.callback_query_handler(func=lambda call: call.data == 'it3')
def buy_12_month(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    label = generate_label()
    payment_link = create_payment_link(config.cena12, label)  # Цена для 12 месяцев — 3000 руб.

    markup = types.InlineKeyboardMarkup()
    link = types.InlineKeyboardButton('Перейти к оплате', url=payment_link)
    markup.add(link)
    markup.add(types.InlineKeyboardButton('Оплатил', callback_data=f'check_payment_{label}'))
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))

    bot.send_message(call.message.chat.id, f"Для оплаты подписки на 12 месяцев перейдите по ссылке и оплатите в течении 2мин \n После успешной оплаты вы получите ваш ключ в течении двух минут.", reply_markup=markup)

    # Запускаем проверку платежа в отдельном потоке
    threading.Thread(target=check_payment_in_background, args=(label, call.message.chat.id, '12_month')).start()

@bot.callback_query_handler(func=lambda call: call.data.startswith('check_payment_'))
def check_payment_button(call):
    label = call.data.split('_')[2]  # Извлекаем label из callback data
    if check_payment_status(label):
        bot.send_message(call.message.chat.id, "Платеж прошел успешно!")
    else:
        bot.send_message(call.message.chat.id, "Оплата не прошла. Попробуйте снова.")

@bot.callback_query_handler(func=lambda call: call.data == 'btn2')
def guide(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)

    markup = types.InlineKeyboardMarkup()
    iphone = types.InlineKeyboardButton('Для Iphone', url=config.iphoneg)
    android = types.InlineKeyboardButton('Для Android', url=config.androidg)
    windows = types.InlineKeyboardButton('Для Windows', url=config.windowsg)
    macos = types.InlineKeyboardButton('Для MacOS', url=config.macosg)
    markup.add(iphone, android)
    markup.add(windows, macos)
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))

    bot.send_message(call.message.chat.id, 'Выбери инструкцию', reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == 'btn4')
def dont_work(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)

    markup = telebot.types.InlineKeyboardMarkup()
    ls = telebot.types.InlineKeyboardButton('Написать в поддержку', url=config.support)
    markup.add(ls)
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))
    bot.send_message(call.message.chat.id, "Нажми на кнопку, чтобы написать в поддержку.", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == 'btn3')
def prem(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)

    markup = telebot.types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton('Назад', callback_data='back_to_menu'))
    bot.send_message(call.message.chat.id, config.premus, reply_markup=markup)


bot.polling(none_stop=True)
